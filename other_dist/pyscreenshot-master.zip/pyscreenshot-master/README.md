# pyscreenshot

### A simple screenshot tool written in Python using Tkinter and PIL.

## How does it look?

![kek](images/kek.png)

>I screenshotted my screenshot tool!? *Ironic*.

## Result

![sample](images/2023-09-13_20-06-20.png)

## Customization

* maybe you want to change the directory?

    `self.imageDir = "./images"  # add your preferred directory here`

* maybe you want to change the file type?
    
    `self.imageType = ".png"  # add your preferred file type here`
